import React, {Component} from 'react';
import axios from 'axios';

class Course extends Component {
  constructor(props) {
    super(props);
    this.state = {
      course: null,
    };

    this.submitStudent = this.submitStudent.bind(this);

  }

  async componentDidMount() {
    await this.refreshCourse();
  }

  async refreshCourse() {
    const { match: { params } } = this.props;
    const course = (await axios.get(`http://localhost:8000/${params.courseId}`)).data;
    this.setState({
      course,
    });
  }

  render() {
    const {course} = this.state;

    if (course === null) return <p>Loading ...</p>;
    return (
      <div className="container">
        <div className="row">
          <div className="jumbotron col-12">
            <h1 className="display-3">{course.title}</h1>
            <p className="lead">{course.description}</p>
            <hr className="my-4" />
            <p>Students:</p>
            {
           course.students.map((student, idx) => (
                <p className="lead" key={idx}>{student.name}</p>
              ))
            }
          </div>
        </div>
      </div>
    )
  }
}

export default Course;
