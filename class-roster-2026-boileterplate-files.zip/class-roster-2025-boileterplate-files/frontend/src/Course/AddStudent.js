import React, {Component, Fragment} from 'react';
import {withRouter} from 'react-router-dom';

class AddStudent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      student: '',
    };
  }

  updateStudent(value) {
    this.setState({
      student: value,
    });
  }

  submit() {
    this.props.submitStudent(this.state.student);

    this.setState({
      student: '',
    });
  }

  render() {
    return (
      <Fragment>
        <div className="form-group text-center">
          <label htmlFor="exampleInputEmail1">Student Name:</label>
          <input
            type="text"
            onChange={(e) => {this.updateStudent(e.target.value)}}
            className="form-control"
            placeholder="Add a new Student."
            value={this.state.student}
          />
        </div>
        <button
          className="btn btn-primary"
          onClick={() => {this.submit()}}>
          Submit
        </button>
        <hr className="my-4" />
      </Fragment>
    )
  }
}

export default withRouter(AddStudent);
