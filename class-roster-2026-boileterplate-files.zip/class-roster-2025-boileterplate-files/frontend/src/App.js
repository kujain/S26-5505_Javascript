import React, { Component } from 'react';
import {Route} from 'react-router-dom';

class App extends Component {
  render() {
    return (
      <div>
        We are ready!
     </div>
    );
  }
}

export default App;
