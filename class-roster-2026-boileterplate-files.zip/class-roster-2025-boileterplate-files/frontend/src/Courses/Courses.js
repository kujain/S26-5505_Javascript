import React, {Component} from 'react';
import {Link} from 'react-router-dom';
import axios from 'axios';

class Courses extends Component {
  constructor(props) {
    super(props);

    this.state = {
      courses: null,
    };
  }

  async componentDidMount() {
    const courses = (await axios.get('http://localhost:8000/')).data;
    this.setState({
      courses,
    });
  }

  render() {
    return (
      <div className="container">
        <div className="row">

          {this.state.courses === null && <p>Loading Courses...</p>}
          {
            this.state.courses && this.state.courses.map(course => (
              <div key={course.id} className="col-sm-12 col-md-4 col-lg-3">
                <Link to={`/course/${course.id}`}>
                  <div className="card text-white bg-success mb-3">
                    <div className="card-header">Students: {course.students}</div>
                    <div className="card-body">
                      <h4 className="card-title">{course.title}</h4>
                      <p className="card-text">{course.description}</p>
                    </div>
                  </div>
                </Link>
              </div>
            ))
          }
        </div>
      </div>
    )
  }
}

export default Courses;
