//import './style.css'
import javascriptLogo from './javascript.svg'
import viteLogo from '/src/img/vite.svg'
import { setupCounter } from './counter.js'

document.querySelector('#app').innerHTML = `
  <div>
    <a href="https://vite.dev" target="_blank">
      <img src="${viteLogo}" class="logo" alt="Vite logo" />
    </a>
    <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank">
      <img src="${javascriptLogo}" class="logo vanilla" alt="JavaScript logo" />
    </a>
    <h1>Hello Vite!</h1>
    <div class="card">
      <button id="counter" type="button"></button>
    </div>
    <p class="read-the-docs">
      Click on the Vite logo to learn more
    </p>
  </div>
`

setupCounter(document.querySelector('#counter'))

let button = document.getElementById('GetUsersAPI');
button.addEventListener("click", getUserData);

async function getUserData() {
  const url = "https://randomuser.me/api/?results=10";
  const headers = {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json'
    }
  };
  const response = await fetch(url, headers);
  const data = await response.json();
  //document.getElementById("Output").innerHTML = JSON.stringify(data.data);

  for( const item of data.results) {
    console.log(item);
    const img = document.createElement('img');
    img.src = item.picture.medium;
    img.alt = item.name.first + ' ' + item.name.last;
    const outp = document.getElementById("Output");
    outp.appendChild(img);
  }
  // for(let i=0; i<data.data.length; i++) {
  //   var img = document.createElement('img');
  //   img.src = resp.data[i].avatar;
  //   console.log(resp.data[i]);

  //   var outp = document.getElementById("Output");
  //   outp.appendChild(img);
  // }
}

